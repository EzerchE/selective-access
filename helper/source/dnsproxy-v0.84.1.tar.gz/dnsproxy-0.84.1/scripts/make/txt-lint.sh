#!/bin/sh

# This comment is used to simplify checking local copies of the script.  Bump
# this number every time a significant change is made to this script.
#
# AdGuard-Project-Version: 14

# Don't use -f, because we use globs in this script.
set -e -o 'pipefail' -u

verbose="${VERBOSE:-0}"
readonly verbose

if [ "$verbose" -gt '0' ]; then
	set -x
fi

# Source the common helpers, including not_found.
. ./scripts/make/helper.sh

# Simple analyzers

# trailing_newlines is a simple check that makes sure that all plain-text files
# have a trailing newlines to make sure that all tools work correctly with them.
trailing_newlines() (
	nl="$(printf '\n')"
	readonly nl

	find_with_ignore \
		-type 'f' \
		'!' '(' \
		-name '*.bin' \
		-o -name '*.exe' \
		-o -name '*.out' \
		-o -name '*.test' \
		-o -name 'dnsproxy' \
		')' \
		-print \
		| while read -r f; do
			final_byte="$(tail -c -1 "$f")"
			if [ "$final_byte" != "$nl" ]; then
				printf '%s: must have a trailing newline\n' "$f"
			fi
		done
)

# trailing_whitespace is a simple check that makes sure that there are no
# trailing whitespace in plain-text files.
trailing_whitespace() {
	find_with_ignore \
		-type 'f' \
		'!' '(' \
		-name '*.bin' \
		-o -name '*.exe' \
		-o -name '*.out' \
		-o -name '*.test' \
		-o -name 'dnsproxy' \
		')' \
		-print \
		| while read -r f; do
			{ grep -e '[[:space:]]$' -n -- "$f" || :; } \
				| sed -e "s:^:${f}\::" -e 's/ \+$/>>>&<<</'
		done
}

# valid_json check ensures that all the .json files in the project are valid and
# well-formatted according to the jq.
valid_json() {
	find_with_ignore \
		-type 'f' \
		-name '*.json' \
		-print \
		| while read -r f; do
			validation_msg="$(jq empty "$f" 2>&1)"
			exitcode="$?"

			if [ "$exitcode" -ne '0' ]; then
				printf 'file %s: %s\n' "$f" "$validation_msg"

				continue
			fi

			if ! jq . "$f" | diff -u "$f" - >/dev/null 2>&1; then
				printf 'file %s has formatting issues\n' "$f"
			fi
		done
}

run_linter -e trailing_newlines

run_linter -e trailing_whitespace

run_linter -e valid_json

go="${GO:-go}"
readonly go

"$go" tool yamlfmt \
	--lint \
	./.github/workflows/*.yaml \
	;

find_with_ignore \
	-type 'f' \
	'(' \
	-name 'Makefile' \
	-o -name '*.conf' \
	-o -name '*.md' \
	-o -name '*.txt' \
	-o -name '*.yaml' \
	-o -name '*.yml' \
	')' \
	-exec "$go" 'tool' 'misspell' '--error' '{}' '+' \
	;
