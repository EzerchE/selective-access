package ratelimit_test

import (
	"context"
	"net/netip"
	"testing"
	"time"

	"github.com/AdguardTeam/dnsproxy/dnsproxytest"
	"github.com/AdguardTeam/dnsproxy/proxy"
	"github.com/AdguardTeam/dnsproxy/ratelimit"
	"github.com/AdguardTeam/golibs/logutil/slogutil"
	"github.com/AdguardTeam/golibs/netutil"
	"github.com/AdguardTeam/golibs/testutil"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// defaultTimeout is a default timeout for tests and contexts.
const defaultTimeout = 1 * time.Second

// Subnet lengths used in tests.
const (
	testSubnetLenIPv4 = 24
	testSubnetLenIPv6 = 64
)

// testLogger is a test logger used in tests.
var testLogger = slogutil.NewDiscardLogger()

func TestMiddleware_Wrap(t *testing.T) {
	t.Parallel()

	testAddr := netip.MustParseAddrPort("192.0.2.0:53")

	testCases := []struct {
		config  *ratelimit.Config
		dctx    *proxy.DNSContext
		wantErr error
		name    string
		want    int
	}{{
		name: "tcp_not_ratelimited",
		config: &ratelimit.Config{
			Logger:        testLogger,
			Ratelimit:     1,
			SubnetLenIPv4: testSubnetLenIPv4,
			SubnetLenIPv6: testSubnetLenIPv6,
		},
		dctx: &proxy.DNSContext{
			Addr:  testAddr,
			Proto: proxy.ProtoTCP,
		},
		want:    2,
		wantErr: nil,
	}, {
		name: "ratelimited",
		config: &ratelimit.Config{
			Logger:        testLogger,
			Ratelimit:     1,
			SubnetLenIPv4: testSubnetLenIPv4,
			SubnetLenIPv6: testSubnetLenIPv6,
		},
		dctx: &proxy.DNSContext{
			Addr:  testAddr,
			Proto: proxy.ProtoUDP,
		},
		want:    1,
		wantErr: proxy.ErrDrop,
	}}

	for _, tc := range testCases {
		called := 0
		mock := &dnsproxytest.Handler{
			OnHandle: func(_ context.Context, p *proxy.Proxy, dctx *proxy.DNSContext) (err error) {
				called++

				return nil
			},
		}

		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()

			mw := ratelimit.NewMiddleware(tc.config)
			wrapped := mw.Wrap(mock)

			ctx := testutil.ContextWithTimeout(t, defaultTimeout)

			err := wrapped.ServeDNS(ctx, nil, tc.dctx)
			require.NoError(t, err, "first request should not be ratelimited")

			err = wrapped.ServeDNS(ctx, nil, tc.dctx)
			assert.Equal(t, tc.wantErr, err)

			assert.Equal(t, tc.want, called)
		})
	}
}

func TestMiddleware_Wrap_allowlist(t *testing.T) {
	t.Parallel()

	var (
		addrAllow     = netip.MustParseAddr("192.0.2.0")
		addrPortAllow = netip.AddrPortFrom(addrAllow, 53)
		addrPortDrop  = netip.MustParseAddrPort("192.0.2.1:53")
	)

	conf := &ratelimit.Config{
		Logger:        testLogger,
		Ratelimit:     1,
		SubnetLenIPv4: testSubnetLenIPv4,
		SubnetLenIPv6: testSubnetLenIPv6,
		AllowlistAddrs: netutil.SliceSubnetSet{
			netip.PrefixFrom(addrAllow, netutil.IPv4BitLen),
		},
	}

	called := 0
	mock := &dnsproxytest.Handler{
		OnHandle: func(_ context.Context, p *proxy.Proxy, dctx *proxy.DNSContext) (err error) {
			called++

			return nil
		},
	}
	mw := ratelimit.NewMiddleware(conf)
	handler := mw.Wrap(mock)

	t.Run("block", func(t *testing.T) {
		dctx := &proxy.DNSContext{
			Addr:  addrPortDrop,
			Proto: proxy.ProtoUDP,
		}

		ctx := testutil.ContextWithTimeout(t, defaultTimeout)

		err := handler.ServeDNS(ctx, nil, dctx)
		require.NoError(t, err, "first request should not be ratelimited")

		err = handler.ServeDNS(ctx, nil, dctx)
		require.Error(t, err, "second request should be ratelimited")
		assert.Equal(t, proxy.ErrDrop, err)

		assert.Equal(t, 1, called)
	})

	t.Run("allow", func(t *testing.T) {
		dctx := &proxy.DNSContext{
			Addr:  addrPortAllow,
			Proto: proxy.ProtoUDP,
		}

		ctx := testutil.ContextWithTimeout(t, defaultTimeout)

		err := handler.ServeDNS(ctx, nil, dctx)
		require.NoError(t, err, "first request should not be ratelimited")

		err = handler.ServeDNS(ctx, nil, dctx)
		require.NoError(t, err, "second request should not be ratelimited due to whitelist")

		assert.Equal(t, 3, called)
	})
}
